addTemplateContent('optionRestoreGraph.html', '<div style="border:1px solid #C0C0C0; padding: 0px 5px 5px 10px;margin-bottom:5px;">'+
'    <label for="restorePositionButton">Restore graph:</label>'+
'    <input type="button" class="restorePositionButton" value="restore" style="width:80px;"/>'+
'</div>');