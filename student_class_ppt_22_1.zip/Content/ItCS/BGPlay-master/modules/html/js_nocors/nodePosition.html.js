addTemplateContent('nodePosition.html', '<textarea class="nodePosition">{{positions}}</textarea>'+
'<div class="nodePositionButtons">'+
'    <input type="button" class="getsvg" value="Get SVG" style="width:80px;"/>'+
'    <input type="button" class="apply" value="Apply" style="width:80px;"/>'+
'</div>');