addTemplateContent('main.html', '<div class="bgplayInfoDiv" style="display:none;"></div>'+
'<div class="bgplayLegendDiv" style="display:none;"></div>'+
'<div class="bgplayCenterDiv">'+
'    <!--<div class="bgplayScreenshot"></div>'+
'    <div class="bgplayFullscreen"></div>-->'+
'    <div class="bgplayGraphDiv" style="display:none;"></div>'+
'    <div class="bgplayControllerDiv" style="display:none;">'+
'    </div>'+
'</div>'+
''+
'<div class="bgplayTimelineDiv" style="display:none;"></div>'+
'<div class="bgplayjsButtonsDiv"><div class="left"></div></div>'+
'');