addTemplateContent('nodePositionFixed.html', '<textarea class="nodePosition">{{positions}}</textarea>'+
'<div class="nodePositionButtons">'+
'    <input type="button" class="getsvg" value="Get SVG" style="width:80px;"/>'+
'</div>');