addTemplateContent('gdbplot.html', '<div>'+
'    <div id="bgplayGDBPlotDiv">'+
'        <canvas id="bgplayGDBPlotCanvas" width="{{width}}" height="{{height}}">Your browser doesn\'t support HTML5 Canvas.</canvas>'+
'    </div>'+
'</div>');