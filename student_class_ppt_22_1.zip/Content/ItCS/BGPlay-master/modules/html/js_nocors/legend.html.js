addTemplateContent('legend.html', '<div>'+
'    <div class="bgplayLegendItem">'+
'        <div style="color:{{nodeColourTargetText}};background:{{nodeColourTarget}};width:100px;height:15px;border:1px solid {{nodeColourTargetBorder}}; border-radius: 15px;">'+
'            Origin AS'+
'        </div>'+
'    </div>'+
''+
'    <div class="bgplayLegendItem">'+
'        <div style="color:{{nodeColourSourceText}};background:{{nodeColourSource}};width:100px;height:15px;border:1px solid {{nodeColourSourceBorder}}; border-radius: 15px;">'+
'            Collector peer'+
'        </div>'+
'    </div>'+
''+
'    <div class="bgplayLegendItem">'+
'        <div style="color:{{nodeColourNormalText}};background:{{nodeColourNormal}};width:100px;height:15px;border:1px solid {{nodeColourNormalBorder}}; border-radius: 15px;">'+
'            Other'+
'        </div>'+
'    </div>'+
''+
'    <div class="bgplayLegendItem">'+
'        <div style="width:100px;height:15px;border-top:2px solid #000000; margin-top:2px;">'+
'            Dynamic path'+
'        </div>'+
'    </div>'+
''+
'    <div class="bgplayLegendItem">'+
'        <div style="width:100px;height:15px;border-top:2px dashed #000000;margin-top:2px;">'+
'            Static path'+
'        </div>'+
'    </div>'+
'</div>');